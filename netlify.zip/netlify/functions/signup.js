// netlify/functions/signup.js
import pkg from 'pg';
const { Pool } = pkg;

// Try both names (Netlify Neon extension sets NETLIFY_DATABASE_URL)
const DB_URL = process.env.NETLIFY_DATABASE_URL || process.env.DATABASE_URL;

const pool = new Pool({
  connectionString: DB_URL,
  ssl: { rejectUnauthorized: false },
});

export async function handler(event) {
  console.log('signup invoked', { method: event.httpMethod, body: event.body });

  if (event.httpMethod !== 'POST') {
    console.log('method not allowed');
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  let json;
  try {
    json = JSON.parse(event.body || '{}');
  } catch (e) {
    console.error('bad JSON', e);
    return { statusCode: 400, body: JSON.stringify({ ok: false, error: 'bad_json' }) };
  }

  const { username, email } = json;
  if (!username || !email) {
    console.log('missing fields');
    return { statusCode: 400, body: JSON.stringify({ ok: false, error: 'missing_fields' }) };
  }

  if (!DB_URL) {
    console.error('No DATABASE_URL/NETLIFY_DATABASE_URL set');
    return { statusCode: 500, body: JSON.stringify({ ok: false, error: 'no_db_url' }) };
  }

  try {
    const q = `
      INSERT INTO users (username, email)
      VALUES ($1, $2)
      ON CONFLICT (email) DO NOTHING
      RETURNING id, username, email, created_at
    `;
    const { rows } = await pool.query(q, [username, email]);
    console.log('insert result', rows);
    return { statusCode: 200, body: JSON.stringify({ ok: true, user: rows[0] || null }) };
  } catch (err) {
    console.error('signup DB error', err);
    return { statusCode: 500, body: JSON.stringify({ ok: false, error: 'server' }) };
  }
}
