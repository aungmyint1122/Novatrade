// netlify/functions/_db.js
import pkg from 'pg';
const { Pool } = pkg;

let pool;
export function getPool() {
  if (!pool) {
    if (!process.env.DATABASE_URL) {
      throw new Error('Missing DATABASE_URL');
    }
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false }, // Neon
    });
  }
  return pool;
}
